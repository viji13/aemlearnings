(function ($, window)
{

	/* Adapting window object to foundation-registry */
    var registry =  $(window).adaptTo("foundation-registry");


    /* Registering custom selector to foundation validation selector using registry - starts  */
   	registry.register("foundation.validation.selector", {

        submittable : "[data-validation=rte-mandatory]",
        candidate : "[data-validation=rte-mandatory]:not([disabled]):not([readonly])",
        exclusion : "[data-validation=rte-mandatory] *"
	}); 

	 /* Registering custom selector to foundation validation selector using registry - ends  */


	/* Registering validator against the selector registered previously - starts*/
    registry.register("foundation.validation.validator",{

       	selector: "[data-validation=rte-mandatory]",
        validate: function (el)
        {

            var element = $(el);
            var elementVal = element.val();
            var contentAsEnter = "<p>&nbsp;";
            var contentAsEnterHtml = "<p> ";
            if(elementVal == "" || (elementVal.indexOf(contentAsEnter)!= -1) || (elementVal.indexOf(contentAsEnterHtml)!= -1))
            {
				return "Please enter richtext content without leading space";
            }
            else
            {
				return;  
            }

        } 
	});
    /* Registering validator against the selector registered previously - ends*/

})
($, window);
